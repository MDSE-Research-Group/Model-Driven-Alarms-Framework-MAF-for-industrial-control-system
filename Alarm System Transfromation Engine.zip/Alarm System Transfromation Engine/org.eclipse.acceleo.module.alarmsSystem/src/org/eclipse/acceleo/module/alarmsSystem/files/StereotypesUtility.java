package org.eclipse.acceleo.module.alarmsSystem.files;


import java.util.List;

import org.eclipse.uml2.uml.Classifier;

import org.eclipse.uml2.uml.Stereotype;


public class StereotypesUtility {

	public boolean hasStereotype(Classifier clazz, String stereotypeName) {
		List<Stereotype> stereotypes = clazz.getAppliedStereotypes();
		for (Stereotype stereotype : stereotypes) {
			if (stereotype.getName().equals(stereotypeName)) {
				return true;
			}
		}
		return false;
	}
}
