package org.eclipse.acceleo.module.alarmsSystem.main;

//import java.awt.EventQueue;
//import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.*;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Dimension;
//import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Component;
//import java.awt.Point;

public class TransformationEngine extends JFrame {
	
	private static final long serialVersionUID = 7526472349569696147L;  // unique id
	
	private JPanel enginePanel;
	private JPanel inputModelPanel;
	private JLabel inputLabel;
    private JTextField inputField;
    private JButton browseModelBtn;
    private JButton informationBtn;
    
    private JPanel destinationPanel;
    private JLabel destinationLabel;
    private JTextField destPathField;
    private JButton browseDestPathBtn;
    
    private JPanel checkBoxPanel;
    private JLabel generateLabel;
    private JCheckBox checkServer;
    private JCheckBox checkJSON;
    private JCheckBox checkiOS;
    private JCheckBox checkAndroid;
    private JButton resetBtn;
    private JButton generateBtn;
    
    private JPanel statusPanel;
    private JLabel statusLabel;
    private JTextArea statusArea;
    private JButton openFolderBtn;
    private JButton closeBtn;
    
    private Utilities.StatusMessageCode status;
   
   
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					TransformationEngine frame = new TransformationEngine();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public TransformationEngine() {
		setFrame();
		initialize();
		removeButtonBorders();
		setActionListerners();
		setTextFieldDelegateMethods();
	}
	
	private void setFrame() {
		setTitle("Transformation Engine");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1066, 628);
		
		JLabel bgLabel = new JLabel("");
		bgLabel.setIcon(new ImageIcon(TransformationEngine.class.getResource("/org/eclipse/acceleo/module/alarmsSystem/main/resources/empty_background.png")));
 		setContentPane(bgLabel);
 		
 		enginePanel = new JPanel();
 		enginePanel.setAlignmentY(Component.TOP_ALIGNMENT);
 		enginePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		getContentPane().add(enginePanel);
		enginePanel.setBounds(new Rectangle(20, 10, 1050, 537));
		enginePanel.setOpaque(false);
		enginePanel.setLayout(null);
		
		inputModelPanel = new JPanel();
		inputModelPanel.setOpaque(false);
		enginePanel.add(inputModelPanel);
		inputModelPanel.setBounds(new Rectangle(0, 10, 1050, 60));
		
		destinationPanel = new JPanel();
		destinationPanel.setOpaque(false);
		enginePanel.add(destinationPanel);
		destinationPanel.setBounds(new Rectangle(0, 70, 1020, 60));
		
		checkBoxPanel = new JPanel();
		checkBoxPanel.setOpaque(false);
		checkBoxPanel.setBounds(0, 130, 1020, 155);
		enginePanel.add(checkBoxPanel);
		
		statusPanel = new JPanel();
		statusPanel.setOpaque(false);
		statusPanel.setBounds(0, 285, 1020, 200);
		enginePanel.add(statusPanel);
		statusPanel.setLayout(null);
	}
	
	private void initialize() {
		inputModelPanel.setLayout(null);
				
		inputLabel = new JLabel("Input UML Model");
		inputLabel.setBounds(54, 10, 120, 30);
		inputLabel.setFont(new Font("Poppins", Font.PLAIN, 13));
		inputLabel.setAlignmentX(0.5f);
		inputModelPanel.add(inputLabel);
		
		inputField = new JTextField();
		inputField.setBounds(186, 7, 421, 35);
		inputField.setPreferredSize(new Dimension(200, 35));
		inputField.setMinimumSize(new Dimension(150, 35));
		inputField.setMaximumSize(new Dimension(400, 35));
		inputModelPanel.add(inputField);
		inputField.setColumns(1);
		
		browseModelBtn = new JButton("");
		browseModelBtn.setBounds(619, 0, 128, 45);
		browseModelBtn.setBorder(null);
		browseModelBtn.setIcon(new ImageIcon(TransformationEngine.class.getResource("/org/eclipse/acceleo/module/alarmsSystem/main/resources/browse_btn.png")));
		inputModelPanel.add(browseModelBtn);
		browseModelBtn.setOpaque(false);
		
		
		informationBtn = new JButton("");
		informationBtn.setBounds(1000, 0, 35, 35);
		informationBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		informationBtn.setBorderPainted(false);
		informationBtn.setIcon(new ImageIcon(TransformationEngine.class.getResource("/org/eclipse/acceleo/module/alarmsSystem/main/resources/information_logo.png")));
		inputModelPanel.add(informationBtn);
		
		
		
		destinationLabel = new JLabel("Destination Folder");
		destinationLabel.setBounds(54, 10, 120, 30);
		destinationLabel.setFont(new Font("Poppins", Font.PLAIN, 13));
		destinationPanel.add(destinationLabel);
		destinationPanel.setLayout(null);
		
		destPathField = new JTextField();
		destPathField.setBounds(186, 7, 421, 35);
		destPathField.setPreferredSize(new Dimension(200, 35));
		destPathField.setMinimumSize(new Dimension(150, 35));
		destPathField.setMaximumSize(new Dimension(400, 35));
		destinationPanel.add(destPathField);
		destPathField.setColumns(1);
		
		browseDestPathBtn = new JButton("");
		browseDestPathBtn.setBounds(619, 0, 128, 45);
		browseDestPathBtn.setBorderPainted(false);
		browseDestPathBtn.setBorder(null);
		browseDestPathBtn.setIcon(new ImageIcon(TransformationEngine.class.getResource("/org/eclipse/acceleo/module/alarmsSystem/main/resources/browse_btn.png")));
		destinationPanel.add(browseDestPathBtn);
		browseDestPathBtn.setOpaque(false);
		checkBoxPanel.setLayout(null);
		
		
		generateLabel = new JLabel("Generate Files");
		generateLabel.setBounds(54, 10, 120, 30);
		generateLabel.setFont(new Font("Poppins", Font.PLAIN, 13));
		checkBoxPanel.add(generateLabel);
		
		checkJSON = new JCheckBox("System Translation in JSON");
		checkJSON.setBounds(186, 37, 215, 25);
		checkBoxPanel.add(checkJSON);
		
		checkServer = new JCheckBox("Alarm Server Code");
		checkServer.setBounds(186, 72, 215, 25);
		checkBoxPanel.add(checkServer);
		
		checkiOS = new JCheckBox("iOS Application Code");
		checkiOS.setBounds(413, 37, 215, 25);
		checkBoxPanel.add(checkiOS);
		
		checkAndroid = new JCheckBox("Android Application Code");
		checkAndroid.setBounds(413, 72, 215, 25);
		checkBoxPanel.add(checkAndroid);
		
		resetBtn = new JButton("");
		resetBtn.setIcon(new ImageIcon(TransformationEngine.class.getResource("/org/eclipse/acceleo/module/alarmsSystem/main/resources/reset_btn.png")));
		resetBtn.setBounds(619, 109, 128, 45);
		checkBoxPanel.add(resetBtn);
		
		generateBtn = new JButton("");
		generateBtn.setIcon(new ImageIcon(TransformationEngine.class.getResource("/org/eclipse/acceleo/module/alarmsSystem/main/resources/generate_btn.png")));
		generateBtn.setBounds(757, 109, 128, 45);
		checkBoxPanel.add(generateBtn);
		
		statusLabel = new JLabel("Status");
		statusLabel.setBounds(54, 10, 120, 30);
		statusPanel.add(statusLabel);
		
		statusArea = new JTextArea();
		statusArea.setEditable(false);
		statusArea.setBounds(64, 45, 600, 95);
		statusPanel.add(statusArea);
		
		openFolderBtn = new JButton("");
		openFolderBtn.setBounds(619, 150, 128, 45);
		openFolderBtn.setIcon(new ImageIcon(TransformationEngine.class.getResource("/org/eclipse/acceleo/module/alarmsSystem/main/resources/open_folder_btn.png")));
		statusPanel.add(openFolderBtn);
		
		closeBtn = new JButton("");
		closeBtn.setBounds(757, 150, 128, 45);
		closeBtn.setIcon(new ImageIcon(TransformationEngine.class.getResource("/org/eclipse/acceleo/module/alarmsSystem/main/resources/close_btn.png")));
		statusPanel.add(closeBtn);
	}
	
	private void removeButtonBorders(){

		checkJSON.setSelected(true);
        generateBtn.setEnabled(false);
        
        Utilities.removeButtonBorders(browseModelBtn);
        Utilities.removeButtonBorders(browseDestPathBtn);
        Utilities.removeButtonBorders(resetBtn);
        Utilities.removeButtonBorders(generateBtn);
        Utilities.removeButtonBorders(openFolderBtn);
        Utilities.removeButtonBorders(closeBtn);
        Utilities.removeButtonBorders(informationBtn);
    }
	
	private void setActionListerners() {
        browseModelBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setFileFilter(new FileNameExtensionFilter("uml", "uml"));
                fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("uml", "uml"));
                if (fileChooser.showOpenDialog(new TransformationEngine()) == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooser.getSelectedFile();
                    inputField.setText(file.getPath());
                }
            }
        });

        browseDestPathBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                if (fileChooser.showOpenDialog(new TransformationEngine()) == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooser.getSelectedFile();
                    destPathField.setText(file.getPath());
                }
            }
        });

        resetBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                inputField.setText("");
                destPathField.setText("");
                statusArea.setText("");
                checkJSON.setSelected(true);
                checkServer.setSelected(false);
                checkiOS.setSelected(false);
                checkAndroid.setSelected(false);
            }
        });

        openFolderBtn.addActionListener(new ActionListener() {
            String path = null;
            @Override
            public void actionPerformed(ActionEvent e) {
                path = destPathField.getText();
                if(path != null && (new File(path)).exists()) {
                    try {
//                        Runtime.getRuntime().exec("explorer.exe /select," + path);
                        String command = "/usr/bin/open";
                        Runtime.getRuntime().exec(new String[]{command, path});
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
        closeBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        informationBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, Constants.TRANSFROMATION_ENGINE_TITLE +" Transformation Engine \n Version: "+
                        Constants.VERSION_NUMBER+" Build: "+ Constants.BUILD_NUMBER, "About", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        generateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                boolean launch = true;
                if(destPathField.getText().trim().isEmpty()) {
                    status = Utilities.StatusMessageCode.EMPTY_REQUIRED_FIELDS;
                    launch = false;
                }
                else {
                    if(!(new File (Utilities.getFromattedFieldText(inputField)).exists())) {
                        status = Utilities.StatusMessageCode.MODEL_NOT_FOUND;
                        launch = false;
                    }
                    else if(!(inputField.getText().endsWith("uml") || inputField.getText().endsWith("UML") || inputField.getText().endsWith("xmi")
                                    || inputField.getText().endsWith("XMI"))) {
                        status = Utilities.StatusMessageCode.MODEL_NOT_SUPPORTED;
                        launch = false;
                    }
                    if (!(new File (Utilities.getFromattedFieldText(destPathField)).exists())) {
                        status = Utilities.StatusMessageCode.FOLDER_DOES_NOT_EXIST;
                        launch = false;
                    }
                }
                if(launch) { launchFunction(launch);} else {
                	status = Utilities.StatusMessageCode.CLEAR;}
            }
        });
    }

    private void launchFunction(boolean launchStatus){

        status = Utilities.StatusMessageCode.CLEAR;
        status = Utilities.StatusMessageCode.CREATING;
        updateStatusMessage(status, "");

        String args[] = new String[2];
        args[0] = Utilities.getFromattedFieldText(inputField);
        args[1] = Utilities.getFromattedFieldText(destPathField);
//        args[2] = checkServer.isSelected() ? "Alarm Server Code(.kt)" : "";
//        args[3] = checkJSON.isSelected() ? "JSON Document(.json)" : "";
//        args[4] = checkiOS.isSelected() ? "iOS Code(.swift)" : "";
//        args[5] = checkAndroid.isSelected() ? "Android Code(.kt)" : "";

//        Model model=Model.getInstance();
//        String[] path=args;
//        model.destPath =path;
        Generate.main(args);
        updateStatusMessage(Utilities.StatusMessageCode.CREATED, Utilities.getFromattedFieldText(destPathField));
    }

    private void setTextFieldDelegateMethods(){
        destPathField.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                textChangedAction();
            }
            public void removeUpdate(DocumentEvent e) {
                textChangedAction();
            }
            public void insertUpdate(DocumentEvent e) {
                textChangedAction();
            }
            public void textChangedAction() {
                updateGenerateBtnStatus();
            }
        });
    }

    private void updateGenerateBtnStatus()
    {
        if(	!(Utilities.fieldIsEmpty(inputField)) && !(Utilities.fieldIsEmpty(destPathField)) &&
                (checkJSON.isSelected() || checkServer.isSelected() || checkiOS.isSelected() || checkAndroid.isSelected())) { generateBtn.setEnabled(true); }
        else { generateBtn.setEnabled(false); }
    }

    public void updateStatusMessage(Utilities.StatusMessageCode statusCode, String path)
    {
        String statusMessage = "";
        if(statusCode == Utilities.StatusMessageCode.CREATED) {statusMessage = Utilities.getStatusMessage(statusCode) + "at path: "+ path;}else { statusMessage = Utilities.getStatusMessage(statusCode);}
        statusArea.setText(statusMessage);
        statusArea.update(statusArea.getGraphics());
    }
}
