package org.eclipse.acceleo.module.alarmsSystem.main;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
//import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Rectangle;

public class AppWindow {

	private JFrame frame;
	private JPanel mainPanel;
	private JButton modelerBtn;
	private JButton cmBtn;
	private JButton tranformationBtn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AppWindow window = new AppWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AppWindow() {
		initialize();
		removeButtonBorders();
		setActionListerners();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 788, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
		
		JLabel bgLabel = new JLabel("");
		bgLabel.setIcon(new ImageIcon(AppWindow.class.getResource("/org/eclipse/acceleo/module/alarmsSystem/main/resources/background.png")));
		frame.setContentPane(bgLabel);
		
		mainPanel = new JPanel();
		frame.getContentPane().add(mainPanel);
		mainPanel.setBounds(new Rectangle(56, 115, 670, 300));
//		mainPanel.setLayout(new GridLayout(3, 1, 0, 0));
		mainPanel.setOpaque(false);
		
		modelerBtn = new JButton("");
		modelerBtn.setHorizontalAlignment(SwingConstants.LEFT);
		modelerBtn.setIcon(new ImageIcon(AppWindow.class.getResource("/org/eclipse/acceleo/module/alarmsSystem/main/resources/system_modeler.png")));
		modelerBtn.setOpaque(false);
		mainPanel.add(modelerBtn);
		
		tranformationBtn = new JButton("");
		tranformationBtn.setHorizontalAlignment(SwingConstants.LEFT);
		tranformationBtn.setIcon(new ImageIcon(AppWindow.class.getResource("/org/eclipse/acceleo/module/alarmsSystem/main/resources/transformation_engine.png")));
		tranformationBtn.setOpaque(false);
		mainPanel.add(tranformationBtn);
		
		cmBtn = new JButton("");
		cmBtn.setHorizontalAlignment(SwingConstants.LEFT);
		cmBtn.setIcon(new ImageIcon(AppWindow.class.getResource("/org/eclipse/acceleo/module/alarmsSystem/main/resources/configuration_manager.png")));
		cmBtn.setOpaque(false);
		mainPanel.add(cmBtn);
		
	}
	
	 private void removeButtonBorders(){

	        Utilities.removeButtonBorders(modelerBtn);
	        Utilities.removeButtonBorders(cmBtn);
	        Utilities.removeButtonBorders(tranformationBtn);
	    }
	
	private void setActionListerners(){

        modelerBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String command = "/usr/bin/open"; String fileAddress = "/Users/zee/eclipse/modeling-oxygen/Eclipse.app"; File file = new File(fileAddress);
                    Runtime.getRuntime().exec(new String[]{command, file.getAbsolutePath()});
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });
        cmBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String command = "/usr/bin/open"; String fileAddress = "/Applications/Google Chrome.app"; File file = new File(fileAddress);
//                    Runtime.getRuntime().exec(new String[]{command, file.getAbsolutePath()});
                    Runtime.getRuntime().exec(new String[]{command, "-a", file.getAbsolutePath(), "http://mb21.github.io/JSONedit/"});

                } catch (IOException ex) { System.out.println(ex.getMessage());}
            }
        });
        tranformationBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TransformationEngine tEngine = new TransformationEngine();
                tEngine.setVisible(true);
            }
        });
    }
	

}
