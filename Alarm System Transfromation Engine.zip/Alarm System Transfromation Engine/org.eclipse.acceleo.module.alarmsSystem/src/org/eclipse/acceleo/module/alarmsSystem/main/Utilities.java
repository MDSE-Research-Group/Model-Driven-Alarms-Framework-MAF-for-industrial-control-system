package org.eclipse.acceleo.module.alarmsSystem.main;

import javax.swing.*;
import java.awt.*;

public class Utilities {

    public static enum StatusMessageCode {
        CLEAR(-1),
        CREATING(0),
        CREATED(1),
        CANNOT_OPEN(2),
        NOT_CREATED(3),
        CREATED_WITH_ERRORS(4),
        MODEL_NOT_FOUND(5),
        MODEL_NOT_SUPPORTED(6),
        ILLEGAL_FILE_NAME(7),
        FOLDER_DOES_NOT_EXIST(8),
        EMPTY_REQUIRED_FIELDS(9);

        private final int statusCode;

        StatusMessageCode(int statusCode) {
            this.statusCode = statusCode;
        }
        public int getStatusCode() {
            return this.statusCode;
        }
    }

    public static JLabel getBackgroundLabel(String imagePath){
        ImageIcon icon = getIconFromImage(imagePath);
        JLabel bgLabel = new JLabel();
        bgLabel.setIcon(icon);
        bgLabel.setLayout(new GridLayout());
        return  bgLabel;
    }

    public static ImageIcon getIconFromImage(String imagePath){
        String urlToImage = imagePath;
        Image bgImage = new ImageIcon(urlToImage).getImage();
        ImageIcon icon = new ImageIcon(bgImage);
        return icon;
    }
    
    public static void removeButtonBorders(JButton button){
        button.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        button.setContentAreaFilled(false);
    }

    public static String getFromattedFieldText(JTextField textField){
        String fieldText = textField.getText().replace('\\', '/');
        return fieldText;
    }
    public static boolean fieldIsEmpty(JTextField textField){
        boolean isFieldEmpty = textField.getText().trim().isEmpty();
        return isFieldEmpty;
    }

    public static String getStatusMessage(StatusMessageCode status)
    {
        String msg;
        switch (status) {
            case CLEAR:
                msg = "";
                break;
            case CREATING:
                msg = "Generating...";
                break;
            case CREATED:
                msg = "Successfully generated files.";
                break;
            case CREATED_WITH_ERRORS:
                msg = "Files generated with errors.";
                break;
            case MODEL_NOT_FOUND:
                msg = "Input model not found. Please check the path and name.";
                break;
            case MODEL_NOT_SUPPORTED:
                msg = "Input model is not supported";
                break;
            case ILLEGAL_FILE_NAME:
                msg = "File name contains an illegal character. Please check the name.";
                break;
            case FOLDER_DOES_NOT_EXIST:
                msg = "Output folder does not exists. Please enter a valid location.";
                break;
            case EMPTY_REQUIRED_FIELDS:
                msg = "Some required fields are empty. Please enter required values.";
                break;
            default:
                msg = "";
        }
        return msg;
    }
}

