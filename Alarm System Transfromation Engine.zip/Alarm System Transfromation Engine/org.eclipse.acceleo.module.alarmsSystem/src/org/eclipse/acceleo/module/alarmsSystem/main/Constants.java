package org.eclipse.acceleo.module.alarmsSystem.main;
import java.awt.*;
public class Constants {

	public static String TRANSFROMATION_ENGINE_TITLE = "Model-Driven Alarm Server and Mobile Clients for PCS";
	public static String BUILD_NUMBER = "1.0";
	public static String VERSION_NUMBER = "1.0";
	public static Color LABEL_BORDER_COLOR = Color.getHSBColor(215,43, 75);
}
